import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentByUPIComponent } from './payment-by-upi.component';

describe('PaymentByUPIComponent', () => {
  let component: PaymentByUPIComponent;
  let fixture: ComponentFixture<PaymentByUPIComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PaymentByUPIComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PaymentByUPIComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
