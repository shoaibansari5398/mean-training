import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-upi',
  standalone: false,
  templateUrl: './payment-by-upi.component.html',
  styleUrl: './payment-by-upi.component.css',
})
export class PaymentByUPIComponent {
 
}
