import { parseHostBindings } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-product-details',
  standalone: false,
  templateUrl: './product-details.component.html',
  styleUrl: './product-details.component.css'
})
export class ProductDetailsComponent implements OnInit {

  selectedProductId:number;

  constructor(private route:ActivatedRoute){
    this.selectedProductId=1;
  }

  ngOnInit() {

    if(this.route.snapshot.paramMap.has('productId')){

      this.selectedProductId = parseInt(this.route.snapshot.paramMap.get('productId')??"-1");
    }
    else{
      this.selectedProductId = -1;
    }
      
  }

}
