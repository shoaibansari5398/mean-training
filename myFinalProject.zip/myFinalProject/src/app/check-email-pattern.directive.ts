import { Directive } from '@angular/core';
import {
  AbstractControl,
  NG_VALIDATORS,
  ValidationErrors,
  Validators,
} from '@angular/forms';
import { validatePasswordPattern } from './ValidatorFunations/validatePasswordPattern';

@Directive({
  standalone: false,
  selector: '[appCheckPasswordPattern]',
  providers: [
    {
      provide: NG_VALIDATORS,
      useExisting: CheckEmailPatternDirective,
      multi: true,
    },
  ],
})
export class CheckEmailPatternDirective implements Validators {
  constructor() {}

  validate(control: AbstractControl): ValidationErrors | null {
    return validatePasswordPattern()(control);
  }
}
