import { SearchArrPipe } from './search-arr.pipe';

describe('SearchArrPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchArrPipe();
    expect(pipe).toBeTruthy();
  });
});
