import { Injectable } from '@angular/core';
import { Cart } from './Cart';

@Injectable()
export class CartManagementService {
  cartArr: Cart[];
  constructor() {
    this.cartArr = [];
  }
  addCartItem(cartObj: Cart) {
    const productExistInCart = this.cartArr.find(
      (item) => item.productId === cartObj.productId
    );
    if (productExistInCart) {
      productExistInCart.quantitySelected += cartObj.quantitySelected;
    } else {
      this.cartArr.push(cartObj);
    }
  }
  getAllCartItems() {
    return this.cartArr;
  }
  deleteCartItem(productId: number) {
    var pos = this.cartArr.findIndex((item) => item.productId == productId);
    if (pos >= 0) {
      this.cartArr.splice(pos, 1);
      return true;
    } else {
      return false;
    }
  }
}
