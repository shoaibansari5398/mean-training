import { Component, EventEmitter, inject, Output } from '@angular/core';
import { Products } from '../../model/Products';
import { Cart } from '../Cart';
import { Router } from '@angular/router';
import { ProductManagementService } from '../product-management.service';

@Component({
  selector: 'app-product-display',
  standalone: false,
  templateUrl: './product-display.component.html',
  styleUrl: './product-display.component.css',
})
export class ProductDisplayComponent {
  productsArr: Products[];
  showAddToCart: boolean;
  selectedProduct: Products | null;
  productManagementService: ProductManagementService;
  // cart: any[];
  @Output() cartChanged: EventEmitter<Cart[]> = new EventEmitter<Cart[]>();

  constructor(private router: Router) {
    this.productManagementService = inject(ProductManagementService);
    this.showAddToCart = false;
    this.selectedProduct = null;
    // this.cart = [];
    this.productsArr = this.productManagementService.getAllProductsItems();
  }

  addToCart(selectedProduct: Products) {
    console.log('add cart clicked');
    this.selectedProduct = selectedProduct;
    this.showAddToCart = true;
  }

  sendDataFromAddToCartToPDEventHandler(cartObj: Cart | null) {
    if (cartObj != null) {
      const pos = this.productsArr.findIndex(
        (product) => product.productId == cartObj.productId
      );

      if (pos >= 0) {
        this.productsArr[pos].quantity -= cartObj.quantitySelected;
      }

      // this.cart.push(cartObj);

      // this.cartChanged.emit(this.cart); // Emit updated cart

      this.showAddToCart = false;
      this.selectedProduct = null;
    }
  }

  sendCancelEventFromAddToCartPDEventHandler() {
    this.showAddToCart = false;
    // selectProduct--null
    this.selectedProduct = null;
  }

  detailseventHandler(selectedProduct: Products) {
    this.router.navigate(['productDetails', selectedProduct.productId]);
  }
}
