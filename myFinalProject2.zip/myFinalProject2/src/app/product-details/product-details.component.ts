import { parseHostBindings } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Products } from '../../model/Products';
import { ProductManagementService } from '../product-management.service';
@Component({
	selector: 'app-product-details',
	standalone: false,
	templateUrl: './product-details.component.html',
	styleUrl: './product-details.component.css',
})
export class ProductDetailsComponent implements OnInit {
	selectedProductId: number;
	selectedProduct: Products | null;


	constructor(private route: ActivatedRoute,private productManagementService: ProductManagementService) {
		this.selectedProductId = 1;
		this.selectedProduct = null;
	}

	ngOnInit() {
		if (this.route.snapshot.paramMap.has("productId")) {
			this.selectedProductId = parseInt(this.route.snapshot.paramMap.get("productId") ?? "-1");
			this.productManagementService.getproductInfo(this.selectedProductId)
				.subscribe({
					next: (response) => {
						console.log("Response from the fet request to /products", response);
						this.selectedProduct = response;
					},
					error: (err) => {
						console.log(err);
						this.selectedProduct = null;
					}

				})

		}
		else {
			this.selectedProductId = -1;
		}
	}
}
