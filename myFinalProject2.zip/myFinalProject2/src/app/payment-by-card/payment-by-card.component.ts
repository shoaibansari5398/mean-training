import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-card',
  standalone: false,
  templateUrl: './payment-by-card.component.html',
  styleUrl: './payment-by-card.component.css'
})
export class PaymentByCardComponent {

}
