import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';
import { Products } from '../model/Products';

@Injectable({
  providedIn: 'root',
})
export class TalkWithServerService {
  constructor(private httpClient: HttpClient) {}
  getProductsArr(): Observable<Products[]> {
    var serverUrl = 'http://localhost:3000/products';
    return this.httpClient
      .get<{ data: Products[]; status: string }>(serverUrl)
      .pipe(map((response) => response['data']));
  }

  getParticularProduct(productId: number): Observable<Products> {
    var serverUrl = 'http://localhost:3000/products/' + productId;

    return this.httpClient
      .get<{ data: Products; status: string }>(serverUrl)
      .pipe(map((response) => response.data));
  }
}
