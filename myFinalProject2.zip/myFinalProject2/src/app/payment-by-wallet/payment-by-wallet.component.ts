import { Component } from '@angular/core';

@Component({
  selector: 'app-payment-by-wallet',
  standalone: false,
  templateUrl: './payment-by-wallet.component.html',
  styleUrl: './payment-by-wallet.component.css',
})
export class PaymentByWalletComponent {
  walletId: string = '';
  amount: number | null = null;

  onSubmit() {
    alert(
      `Processing payment with Wallet ID: ${this.walletId} for ₹${this.amount}`
    );
  }
}
