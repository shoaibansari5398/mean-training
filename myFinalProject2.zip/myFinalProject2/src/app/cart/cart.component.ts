import { Component, Input } from '@angular/core';
import { Router } from '@angular/router';
import { CartManagementService } from '../cart-management.service';

@Component({
  selector: 'app-cart',
  standalone: false,
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css',
})
export class CartComponent {
  // @Input() cartItems: any[] =[]
  cartArr: any[] = [];

  constructor(private router: Router, private cms: CartManagementService) {
    this.cartArr = cms.getAllCartItems();
  }

  proceedToPaymentHandler() {
    this.router.navigate(['/payments']);
  }

  totalAmount(): number {
    return this.cartArr.reduce(
      (total, item) => total + item.price * item.quantitySelected,
      0
    );
  }
}
